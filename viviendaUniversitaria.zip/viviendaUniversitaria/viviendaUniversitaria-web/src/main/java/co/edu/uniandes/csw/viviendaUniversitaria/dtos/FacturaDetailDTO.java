/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniandes.csw.viviendaUniversitaria.dtos;

import co.edu.uniandes.csw.viviendaUniversitaria.entities.FacturaEntity;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author je.bejarano10
 */
public class FacturaDetailDTO extends FacturaDTO{
    private EstudianteDTO estudiante;
    private List <DetalleServicioDTO> detalleServicio;
    private List <DetalleReservaDTO> detalleReserva;

    public EstudianteDTO getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(EstudianteDTO estudiante) {
        this.estudiante = estudiante;
    }

    public List<DetalleServicioDTO> getDetalleServicio() {
        return detalleServicio;
    }

    public void setDetalleServicio(List<DetalleServicioDTO> detalleServicio) {
        this.detalleServicio = detalleServicio;
    }

    public List<DetalleReservaDTO> getDetalleReserva() {
        return detalleReserva;
    }

    public void setDetalleReserva(List<DetalleReservaDTO> detalleReserva) {
        this.detalleReserva = detalleReserva;
    }

    public HospedajeDetailDTO getHospedaje() {
        return hospedaje;
    }

    public void setHospedaje(HospedajeDetailDTO hospedaje) {
        this.hospedaje = hospedaje;
    }
    private HospedajeDetailDTO hospedaje;
    
    public FacturaDetailDTO(){
        super();
    }
    public FacturaDetailDTO(FacturaEntity facturaEntity){
       super(facturaEntity);
        if(facturaEntity!= null){
            if(facturaEntity.getEstudiante()!=null){
           estudiante= new EstudianteDTO(facturaEntity.getEstudiante());
            }
            else{
                facturaEntity.setEstudiante(null);
            }
            if(facturaEntity.getHospedaje()!=null){
           hospedaje=facturaEntity.getHospedaje();
            }
            else{
            facturaEntity.setHospedaje(null);
        }
           detalleServicio= new ArrayList<>();
           for (DetalleServicioEntity entityDetalleServicio : facturaEntity.getDetalleServicio()) {
                detalleServicio.add(new DetalleServicioDTO(entityDetalleServicio));
            }
           detalleReserva= new ArrayList<>();
           for (DetalleReservaEntity entityDetalleReserva : facturaEntity.getDetalleReserva()) {
                detalleReserva.add(new DetalleReservaDTO(entityDetalleReserva));
            }
           
        }
    }
    @Override 
    public FacturaEntity toEntity(){
        FacturaEntity entity= super.toEntity();
        if(estudiante!=null){
            entity.setEstudiante(estudiante);
        }
        if(hospedaje!=null){
            entity.setHospedaje(hospedaje);
        }
        if(detalleServicio!=null){
            List<DetalleServicio> detalleServicioEntity= new ArrayList<>();
            for(DetalleServicioDTO dtoDetalleServicio : detalleServicio){
                detalleServicio.add(dtoDetalleServicio.toEntity());
            }
            entity.setDetalleServicio(detalleServicioEntity);     
        }
        if(detalleReserva!=null){
            List<DetalleReserva> detalleReservaEntity= new ArrayList<>();
            for(DetalleReservaDTO dtoDetalleReserva : detalleReserva){
                detalleReserva.add(dtoDetalleReserva.toEntity());
            }
            entity.setDetalleReserva(detalleReservaEntity);     
        }
        return entity;
    }
    
    
    
    
}
