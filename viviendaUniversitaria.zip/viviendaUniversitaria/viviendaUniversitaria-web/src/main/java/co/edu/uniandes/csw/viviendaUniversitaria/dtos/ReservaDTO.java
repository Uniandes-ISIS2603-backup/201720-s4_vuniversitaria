/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniandes.csw.viviendaUniversitaria.dtos;

import co.edu.uniandes.csw.viviendaUniversitaria.entities.ReservaEntity;
import java.util.Date;

/**
 *
 * @author je.bejarano10
 */
public class ReservaDTO {
 private Long id;
    private int cedulaHuesped;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getCedulaHuesped() {
        return cedulaHuesped;
    }

    public void setCedulaHuesped(int cedulaHuesped) {
        this.cedulaHuesped = cedulaHuesped;
    }

    public int getIdHospedaje() {
        return idHospedaje;
    }

    public void setIdHospedaje(int idHospedaje) {
        this.idHospedaje = idHospedaje;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
    private int idHospedaje;
    private Date fechaInicio;
    private Date fechaFin;

    /**
     * 
     */
    public ReservaDTO() {
    }

    /**
     * Crea un objeto AuthorDTO a partir de un objeto AuthorEntity.
     *
     * @param entity Entidad AuthorEntity desde la cual se va a crear el nuevo
     * objeto.
     * 
     */
    public ReservaDTO(ReservaEntity entity) {
        if (entity != null) {
            this.id = entity.getId();
            this.cedulaHuesped = entity.getCedulaHuesped();
            this.idHospedaje = entity.getIdHospedaje();
            this.fechaInicio = entity.getFechaInicio();
            this.fechaFin = entity.getFechaFin();
        }
    }

    /**
     * Convierte un objeto AuthorDTO a AuthorEntity.
     *
     * @return Nueva objeto AuthorEntity.
     * 
     */
    public ReservaEntity toEntity() {
        ReservaEntity entity = new ReservaEntity();
        entity.setId(this.id);
        entity.setIdHospedaje(this.idHospedaje);
        entity.setCedulaHuesped(this.cedulaHuesped);
        entity.setFechaInicio(this.fechaInicio);
        entity.setFechaFin(this.fechaFin);
        return entity;
    }
}
