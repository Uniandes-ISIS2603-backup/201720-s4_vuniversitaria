/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniandes.csw.viviendaUniversitaria.dtos;

import co.edu.uniandes.csw.viviendaUniversitaria.entities.FacturaEntity;
import java.util.Date;

/**
 *
 * @author je.bejarano10
 */
public class FacturaDTO {

    private Long id;
    private Date fecha;
    private double total;
    private double iva;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }
   public FacturaDTO(){
       
   }

    /**
     * Crea un objeto AuthorDTO a partir de un objeto AuthorEntity.
     *
     * @param entity Entidad AuthorEntity desde la cual se va a crear el nuevo
     * objeto.
     * 
     */
    public FacturaDTO(FacturaEntity entity) {
        if (entity != null) {
            this.id = entity.getId();
            this.fecha=entity.getFecha();
            this.iva=entity.getIva();
            this.total=entity.getTotal();
        }
    }

    /**
     * Convierte un objeto AuthorDTO a AuthorEntity.
     *
     * @return Nueva objeto AuthorEntity.
     * 
     */
    public FacturaEntity toEntity() {
        FacturaEntity entity = new FacturaEntity();
        entity.setId(this.id);
        entity.setIva(this.iva);
        entity.setTotal(this.total);
        entity.setFecha(fecha);
        return entity;
    }

}
